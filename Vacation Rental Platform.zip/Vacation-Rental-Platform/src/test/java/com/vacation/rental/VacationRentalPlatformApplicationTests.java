package com.vacation.rental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VacationRentalPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
